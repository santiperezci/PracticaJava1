import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
public class Amazon {
		static User usuario;
		static Users usuarios;
		static boolean usuarioRegistrado;
	public static void main (String[] arg){
		usuarioRegistrado=false;
		System.out.println("Bienvenido a nuestra web");
		leerPropiedades();
		usuarios=new Users();
		if(usuarios.verificar(usuario)==false) {
			System.out.println("Usuario no registrado");
			registrarUsuario();
		}
		else {
			usuarioRegistrado=true;
			System.out.println("Bienvenido, �stos son dus datos");
			System.out.println(usuario.email);
	        System.out.println(usuario.name);
	        System.out.println(usuario.password);
		}
		Categor�as amazonia=new Categor�as();
		System.out.println("Gracias por comprar en Amazonia");
		
	}
	public static void registrarUsuario() {
		Scanner entradaEscaner = new Scanner (System.in);
		System.out.println("Escribe tu nombre de usuario");
		String usuario = "";
        usuario = entradaEscaner.nextLine ();
		System.out.println("Escriba su email");
		String email = "";
        email = entradaEscaner.nextLine ();
        System.out.println("Escriba su contrase�a");
        String contrase�a = "";
        contrase�a = entradaEscaner.nextLine ();
        escribirPropiedades(usuario, email, contrase�a);
	}
	public static void escribirPropiedades(String usuario, String email, String contrase�a) {
		 Properties properties = new Properties();
		 properties.setProperty("username", usuario);
		 properties.setProperty("email", email);
		 properties.setProperty("password", contrase�a);
		 try {
			 properties.store(new FileWriter("Config"),"");
			 boolean a�adido=usuarios.addUsuario(usuario, email, contrase�a);
			 if(a�adido==true) {
				 usuarioRegistrado=true;
				 System.out.println("Bienvenido, �stos son dus datos");
				 System.out.println(email);
			     System.out.println(usuario);
			     System.out.println(contrase�a);
			 }
			 else {
				 System.out.println("Se ha producido un error al a�adir al usuario");
			 }
		 }
		 catch(IOException ioex) {
			 System.out.println(ioex.getMessage());
		 }
	}
	public static void leerPropiedades() {
		try(FileReader reader =  new FileReader("config")) {
	        Properties properties = new Properties();
	        properties.load(reader);
	        String email = properties.getProperty("email");
	        String username = properties.getProperty("username");
	        String password = properties.getProperty("password");
	        if(email!=null && username!=null && password!=null) {
	        	usuario=new User(username, email, password);
	        	/*System.out.println(usuario.email);
		        System.out.println(usuario.name);
		        System.out.println(usuario.password);*/
	        }
	        
	       }catch (Exception e) {;
	       e.printStackTrace();
	       }
	}
}
