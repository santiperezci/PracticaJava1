import java.lang.reflect.Array;

public class Categor�as {
	int numCategorias;
	Categoria [ ] nombresCategorias;
	public Categor�as() {
		nombresCategorias =new Categoria[] {new Categoria("Alimentos","Al"),new Categoria("Moda","Mod"),new Categoria("Electr�nica","El"),
				new Categoria("Libros","lib")};
		nombresCategorias[0].setNombresSubCategorias(new String[]{"Alimentos y bebidas", "productos eco", "bebidas alcoh�loicas"});
		nombresCategorias[1].setNombresSubCategorias(new String[] {"Mujer", "Hombre", "Beb�"});
		nombresCategorias[2].setNombresSubCategorias(new String[] {"Fotograf�a", "M�viles", "Inform�tica"});
		nombresCategorias[3].setNombresSubCategorias(new String[] {"Electr�nicos", "Infantiles", "Poes�a"});
		numCategorias=4;
	}
	
}
